@echo off
setlocal enabledelayedexpansion
title ALZY - GitHub upload

echo.
echo  ALZY to GitHub upload
echo  --------------------------------------------
echo.

REM ---------- 1. project folder? ----------
echo  1. Checking the project folder
if not exist "package.json" goto :wrongfolder
if not exist "routes" goto :wrongfolder
echo     OK - found the ALZY project in %CD%
goto :checkgit

:wrongfolder
echo     X This is not the ALZY folder (no package.json / routes).
echo.
echo       Open the folder that contains server.js in File Explorer,
echo       click the address bar, type  cmd  and press Enter.
echo       Then run this script again.
echo.
pause
exit /b 1

REM ---------- 2. git installed? ----------
:checkgit
echo.
echo  2. Checking Git
where git >nul 2>&1
if errorlevel 1 goto :nogit
for /f "tokens=3" %%v in ('git --version') do set GITVER=%%v
echo     OK - Git !GITVER!
goto :checkidentity

:nogit
echo     X Git is not installed.
echo.
echo       Download it from  https://git-scm.com/download/win
echo       Run the installer and click Next through every screen.
echo       Then CLOSE this window, open a new one, and run this again.
echo.
pause
exit /b 1

REM ---------- 3. identity ----------
:checkidentity
echo.
echo  3. Checking your Git identity
for /f "delims=" %%e in ('git config --global user.email 2^>nul') do set GHEMAIL=%%e
if not defined GHEMAIL goto :askidentity
echo     OK - using !GHEMAIL!
goto :askuser

:askidentity
set /p GHEMAIL="     Your GitHub email: "
if "!GHEMAIL!"=="" (echo     X An email is required. & pause & exit /b 1)
set /p GHNAME="     Your name (e.g. Thabo Dlamini): "
if "!GHNAME!"=="" set GHNAME=ALZY Developer
git config --global user.email "!GHEMAIL!"
git config --global user.name "!GHNAME!"
echo     Saved.
goto :askuser

REM ---------- 4. username ----------
:askuser
echo.
echo  4. Your GitHub username
echo     This is the part after github.com/ in your profile URL.
set /p GITHUBUSER="     GitHub username: "
if "!GITHUBUSER!"=="" (echo     X A username is required. & pause & exit /b 1)
set REPOURL=https://github.com/!GITHUBUSER!/alzy.git
echo     Target: !REPOURL!
echo.
echo     Make sure you created the repository first:
echo       https://github.com/new  -^>  name it  alzy  -^>  leave every box UNTICKED
echo.
pause

REM ---------- 5. prepare ----------
echo.
echo  5. Preparing your files
if exist ".git" goto :havegit
git init -q
echo     Initialised a new Git repository
goto :addfiles

:havegit
echo     Git already initialised here

:addfiles
findstr /x /c:"node_modules/" .gitignore >nul 2>&1 || echo node_modules/>> .gitignore
findstr /x /c:"data/*.db" .gitignore >nul 2>&1 || echo data/*.db>> .gitignore
findstr /x /c:"*.log" .gitignore >nul 2>&1 || echo *.log>> .gitignore
git add .
git commit -qm "ALZY - Eswatini agriculture and food marketplace"
if errorlevel 1 (
  echo     Nothing new to commit ^(already committed earlier^)
) else (
  echo     Committed your files
)
git branch -M main
echo     Branch is 'main'

REM ---------- 6. remote ----------
echo.
echo  6. Connecting to GitHub
git remote get-url origin >nul 2>&1
if errorlevel 1 (
  git remote add origin "!REPOURL!"
  echo     Connected to !REPOURL!
) else (
  git remote set-url origin "!REPOURL!"
  echo     Already connected - remote set to !REPOURL!
)

REM ---------- 7. push ----------
echo.
echo  7. Uploading
echo.
echo     If a browser window opens, sign in to GitHub and approve.
echo     If it asks for a password, you need a Personal Access Token:
echo       https://github.com/settings/tokens  -^>  Generate new token (classic)
echo       -^>  tick "repo"  -^>  Generate  -^>  copy the ghp_... token
echo.
git push -u origin main
if errorlevel 1 goto :pushfailed

echo.
echo     Done! Your code is live at:
echo       https://github.com/!GITHUBUSER!/alzy
echo.
echo  Next: put the site online for free
echo    1. Go to https://render.com and choose Sign in with GitHub
echo    2. Click New -^> Blueprint, pick your "alzy" repository
echo       (render.yaml is already in the repo, so settings fill themselves in)
echo    3. Click Apply. In about 2 minutes you get a public web address.
echo.
pause
exit /b 0

:pushfailed
echo.
echo     X The upload failed. Common causes:
echo.
echo       Authentication failed / could not read Username
echo         ^-^> You need a Personal Access Token, not your password.
echo            https://github.com/settings/tokens  -^>  Generate new token (classic)
echo            tick "repo", generate, copy the ghp_... value, paste as the password.
echo.
echo       Repository not found
echo         ^-^> Check the username spelling, and that you created the repo at
echo            https://github.com/new
echo.
echo       rejected / fetch first
echo         ^-^> The repo already has files ^(you may have ticked "Add a README"^).
echo            Delete and recreate it with every box unticked, then rerun.
echo.
pause
exit /b 1
