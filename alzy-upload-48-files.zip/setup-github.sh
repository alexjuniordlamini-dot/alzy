#!/usr/bin/env bash
# ALZY — one-command GitHub upload helper (macOS / Linux)
#
# Usage:
#   ./setup-github.sh                    # interactive — asks for your username
#   ./setup-github.sh your-username      # non-interactive
#
# It checks everything first, tells you exactly what's wrong, and only then uploads.

set -u

RED=$'\033[31m'; GREEN=$'\033[32m'; YELLOW=$'\033[33m'; BLUE=$'\033[34m'; BOLD=$'\033[1m'; OFF=$'\033[0m'

ok()   { echo "${GREEN}✓${OFF} $1"; }
warn() { echo "${YELLOW}!${OFF} $1"; }
err()  { echo "${RED}✗${OFF} $1"; }
step() { echo; echo "${BOLD}${BLUE}$1${OFF}"; }

echo
echo "${BOLD}ALZY → GitHub upload${OFF}"
echo "────────────────────────────────────────────"

# ---------- 1. are we in the project? ----------
step "1. Checking the project folder"
if [ ! -f package.json ] || [ ! -d routes ]; then
  err "This doesn't look like the ALZY folder (no package.json / routes)."
  echo "   Move into the folder that contains server.js, then run this again:"
  echo "   ${BOLD}cd ~/Desktop/alzy${OFF}"
  exit 1
fi
ok "Found the ALZY project in $(pwd)"

# ---------- 2. is git installed? ----------
step "2. Checking Git"
if ! command -v git >/dev/null 2>&1; then
  err "Git is not installed."
  echo "   macOS:  run  ${BOLD}git --version${OFF}  and click Install when prompted"
  echo "   Ubuntu: ${BOLD}sudo apt install git${OFF}"
  echo "   Then run this script again."
  exit 1
fi
ok "Git $(git --version | awk '{print $3}')"

# ---------- 3. is git configured? ----------
step "3. Checking your Git identity"
if ! git config --global user.email >/dev/null 2>&1 || [ -z "$(git config --global user.email)" ]; then
  warn "Git doesn't know your email yet."
  read -r -p "   Your GitHub email: " ghemail
  if [ -z "$ghemail" ]; then err "An email is required."; exit 1; fi
  git config --global user.email "$ghemail"
  read -r -p "   Your name (e.g. Thabo Dlamini): " ghname
  git config --global user.name "${ghname:-ALZY Developer}"
  ok "Saved — using $ghemail"
else
  ok "Already set ($(git config --global user.email))"
fi

# ---------- 4. username ----------
step "4. Your GitHub username"
USERNAME="${1:-}"
if [ -z "$USERNAME" ]; then
  echo "   This is the part after github.com/ in your profile URL."
  read -r -p "   GitHub username: " USERNAME
fi
if [ -z "$USERNAME" ]; then err "A username is required."; exit 1; fi
REPO_URL="https://github.com/${USERNAME}/alzy.git"
ok "Target: ${REPO_URL}"

# ---------- 5. does the repo exist? ----------
step "5. Checking the repository exists on GitHub"
if command -v curl >/dev/null 2>&1; then
  CODE=$(curl -s -o /dev/null -w "%{http_code}" "https://github.com/${USERNAME}/alzy" 2>/dev/null)
  if [ "$CODE" = "404" ]; then
    err "github.com/${USERNAME}/alzy was not found."
    echo
    echo "   ${BOLD}Create it first — it takes 30 seconds:${OFF}"
    echo "   1. Go to ${BOLD}https://github.com/new${OFF}"
    echo "   2. Repository name: ${BOLD}alzy${OFF}"
    echo "   3. Leave every checkbox UNTICKED"
    echo "   4. Click 'Create repository'"
    echo "   5. Run this script again"
    exit 1
  elif [ "$CODE" = "200" ]; then
    ok "Repository exists"
  else
    warn "Couldn't check automatically (HTTP $CODE) — continuing anyway"
  fi
else
  warn "curl not available — skipping the repository check"
fi

# ---------- 6. prepare the commit ----------
step "6. Preparing your files"
if [ -d .git ]; then
  ok "Git already initialised here"
else
  git init -q
  ok "Initialised a new Git repository"
fi

# make sure the things that must never be uploaded are ignored
grep -qx 'node_modules/' .gitignore 2>/dev/null || echo 'node_modules/' >> .gitignore
grep -qx 'data/*.db'   .gitignore 2>/dev/null || echo 'data/*.db'   >> .gitignore
grep -qx '*.log'       .gitignore 2>/dev/null || echo '*.log'       >> .gitignore

git add .
CHANGES=$(git diff --cached --numstat | wc -l | tr -d ' ')
if [ "$CHANGES" = "0" ]; then
  warn "Nothing new to commit (already committed earlier)"
else
  git commit -qm "ALZY — Eswatini agriculture & food marketplace"
  ok "Committed $CHANGES files"
fi

git branch -M main
ok "Branch is 'main'"

# ---------- 7. connect ----------
step "7. Connecting to GitHub"
if git remote get-url origin >/dev/null 2>&1; then
  CURRENT=$(git remote get-url origin)
  if [ "$CURRENT" != "$REPO_URL" ]; then
    git remote set-url origin "$REPO_URL"
    ok "Updated the remote to $REPO_URL"
  else
    ok "Already connected to $REPO_URL"
  fi
else
  git remote add origin "$REPO_URL"
  ok "Connected to $REPO_URL"
fi

# ---------- 8. push ----------
step "8. Uploading"
echo "   If a browser window opens, sign in to GitHub and approve."
echo "   If it asks for a password, you need a Personal Access Token:"
echo "   ${BLUE}https://github.com/settings/tokens${OFF}  →  Generate new token (classic)  →  tick 'repo'"
echo

if git push -u origin main 2>/tmp/alzy-push-err; then
  echo
  ok "${BOLD}Done!${OFF} Your code is live at:"
  echo "   ${BLUE}https://github.com/${USERNAME}/alzy${OFF}"
  echo
  echo "${BOLD}Next: put the site online for free${OFF}"
  echo "   1. Go to ${BLUE}https://render.com${OFF} and choose 'Sign in with GitHub'"
  echo "   2. Click  New → Blueprint  and pick your 'alzy' repo"
  echo "      (the repo contains render.yaml, so the settings fill themselves in)"
  echo "   3. Click Apply. In ~2 minutes you get a public https://alzy-xxxx.onrender.com"
  echo
else
  PUSH_ERR=$(cat /tmp/alzy-push-err 2>/dev/null)
  echo
  err "The upload failed."
  echo
  case "$PUSH_ERR" in
    *"Authentication failed"*|*"could not read Username"*|*"Invalid username or password"*)
      echo "${BOLD}This is a login problem.${OFF} GitHub does not accept your account password here."
      echo "You need a Personal Access Token:"
      echo "  1. Open ${BLUE}https://github.com/settings/tokens${OFF}"
      echo "  2. Generate new token (classic) → tick the 'repo' box → Generate"
      echo "  3. Copy the token (starts with ghp_)"
      echo "  4. Run this script again and paste it when asked for a password"
      echo
      echo "Or sign in through a browser instead:"
      echo "  ${BOLD}gh auth login${OFF}   (install from https://cli.github.com if needed)"
      ;;
    *"rejected"*|*"fetch first"*|*"non-fast-forward"*)
      echo "The GitHub repo already has commits in it (maybe you ticked 'Add a README')."
      echo "Easiest fix — delete and recreate the repo with all boxes unticked, then rerun."
      echo "Or force your version over the top if you're sure:"
      echo "  ${BOLD}git push -u --force origin main${OFF}"
      ;;
    *"Repository not found"*|*"not found"*)
      echo "GitHub can't find ${REPO_URL}."
      echo "Check the username is spelled correctly, and that you created the repo."
      ;;
    *"Permission denied"*|*"publickey"*)
      echo "SSH key problem. Switch to HTTPS instead:"
      echo "  ${BOLD}git remote set-url origin ${REPO_URL}${OFF}"
      ;;
    *)
      echo "Error from Git:"
      echo "$PUSH_ERR" | sed 's/^/   /'
      ;;
  esac
  exit 1
fi
